import os
from flask import (Flask, redirect, render_template, request,
                   send_from_directory, url_for,jsonify) 
from flask_cors import CORS 
import anthropic
from anthropic import BadRequestError  # Ensure you import BadRequestError
import PyPDF2  
from PyPDF2 import PdfReader
import re
from werkzeug.utils import secure_filename
import sys
import openai
from azure.ai.vision.imageanalysis import ImageAnalysisClient
from azure.ai.vision.imageanalysis.models import VisualFeatures
from azure.core.credentials import AzureKeyCredential
import builtins
import pymupdf


openai.api_type = "YOUR API TYPE"
openai.api_base = "YOUR API BASE"
openai.api_version = "YOUR API VERSION"
openai.api_key = "YOUR API KEY"

os.environ["ANTHROPIC_API_KEY"] = "YOUR ANTHROPIC API KEY" 

try:
    endpoint = 'YOUR ENDPOINT'
    key = 'YOUR KEY'
except KeyError:
    print("Missing environment variable 'VISION_ENDPOINT' or 'VISION_KEY'")
    print("Set them before running this sample.")
    exit()

client = ImageAnalysisClient(endpoint=endpoint,credential=AzureKeyCredential(key)) 


app = Flask(__name__)
CORS(app)
# Ensure there's a folder named 'uploads' in the same directory as this script  
UPLOAD_FOLDER = 'uploads'  
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
@app.route('/')
def index():
   print('Request for index page received')
   return render_template('index.html')

@app.route('/favicon.ico')
def favicon():
    return send_from_directory(os.path.join(app.root_path, 'static'),
                               'favicon.ico', mimetype='image/vnd.microsoft.icon')

@app.route('/hello', methods=['POST'])
def hello():
   name = request.form.get('name')

   if name:
       print('Request for hello page received with name=%s' % name)
       return render_template('hello.html', name = name)
   else:
       print('Request for hello page received with no name or blank name -- redirecting')
       return redirect(url_for('index'))

@app.route('/upload', methods=['POST'])  
def upload_files():  
    if 'pdf1' not in request.files or 'pdf2' not in request.files:  
        return jsonify({'error': 'Missing files'}), 400  
      
    file1 = request.files['pdf1']  
    file2 = request.files['pdf2']  
      
    if file1.filename == '' or file2.filename == '':  
        return jsonify({'error': 'No selected file'}), 400  
      
    # Generating paths for saving files  
    path1 = os.path.join(app.config['UPLOAD_FOLDER'], file1.filename)  
    path2 = os.path.join(app.config['UPLOAD_FOLDER'], file2.filename)  
      
    # Saving files  
    file1.save(path1)  
    file2.save(path2)  
    common_schedules = get_final_schedules(path1, path2)  
    schedules_str = ", ".join(common_schedules) 
   
    return jsonify({  
        'file1_path': path1,  
        'file2_path': path2,  
        'comparison_result': schedules_str  
    })
def get_final_schedules(pdf_v1, pdf_v2):    
    schedules_v1 = get_schedules(pdf_v1)    
    schedules_v2 = get_schedules(pdf_v2)    
    common_schedules = list(set(schedules_v1).intersection(set(schedules_v2)))    
    return common_schedules
def get_schedules(pdf_file):    
    with open(pdf_file, 'rb') as file:    
        reader = PyPDF2.PdfReader(file)    
        schedules = []    
        for page in reader.pages:    
            text = page.extract_text() if page.extract_text() else ""    
            match = re.search(r'Schedule\s+([A-Z]+[-A-Z]*).*', text)    
            if match and ',' not in match.group():    
                schedule = match.group()    
                if schedule not in schedules:    
                    schedules.append(schedule)    
    return schedules
@app.route('/upload1', methods=['POST'])  
def upload_files_with_schedule():  
    if 'pdf1' not in request.files or 'pdf2' not in request.files:  
        return jsonify({'error': 'Missing files'}), 400  
      
    file1 = request.files['pdf1']  
    file2 = request.files['pdf2']  
    schedule=request.form['schedule']  
    if file1.filename == '' or file2.filename == '':  
        return jsonify({'error': 'No selected file'}), 400  
      
    # Generating paths for saving files  
    path1 = os.path.join(app.config['UPLOAD_FOLDER'], file1.filename)  
    path2 = os.path.join(app.config['UPLOAD_FOLDER'], file2.filename)  
      
    # Saving files  
    file1.save(path1)  
    file2.save(path2)  
    #common_schedules = get_final_schedules(path1, path2)  
    #schedules_str = ", ".join(common_schedules)  # Convert list of schedules to a string   
    # Here you could add your logic for comparing the files or any other processing  
    #comparison_result = "Comparison pending." # Placeholder  
    #comparison_result = f"Files are saved. Comparison pending. File1 path: {path1}, File2 path: {path2}" 
    # Returning paths of the saved files along with any result of comparison
    result_output=compare_schedules(path1,path2,schedule)
    return jsonify({  
        'file1_path': path1,  
        'file2_path': path2,  
        'comparison_result1': result_output  
    })  

def categorize_differences(differences):
    category_prompt = ''' 
    You will be provided with points of differences between two versions of a document. You have to categorize them into the following categories:
    1. Missing
    2. Extra/Additions
    3. Changes

    NOTE: Donot exclude any points provided in the input
    NOTE: Donot give any explanation
    NOTE: Put None if any category is empty
    NOTE: The differences should be unordered
    '''
    
    client = anthropic.Anthropic(
            # defaults to os.environ.get("ANTHROPIC_API_KEY")
            api_key= os.environ.get("ANTHROPIC_API_KEY")
        )

    user_prompt= f'''
    Differences:
    {differences}

    '''
    message = client.messages.create(
        model="claude-3-opus-20240229",
        max_tokens=1000,
        temperature=0.3,
        system=category_prompt,
        messages=[
            {"role": "user", "content": user_prompt}
        ]
    )
    return message.content[0].text


# Function to call to compare two pdf files based on a selected schedules and get a list of Differences
# Returns a string with page-by-page comparison of a particular schedule
def find_schedules_page(file_name, schedule):  
    with open(file_name, 'rb') as file:  
        pdf_reader = PyPDF2.PdfReader(file)  
        result = []
        for page_number in range(len(pdf_reader.pages)):  
            page_text = pdf_reader.pages[page_number].extract_text()  
            if schedule in page_text:  
                result.append(page_number+1)  
    return result 
def compare_schedules(pdf_v1,pdf_v2, schedule): 
    v1_pages = find_schedules_page(pdf_v1,schedule)
    v2_pages = find_schedules_page(pdf_v2,schedule)
    with open(pdf_v1, 'rb') as file:    
        pdf_reader = PyPDF2.PdfReader(file)  
        prev_text = []  
        for page_number in v1_pages:  # Here page_number is the actual page number, not the index  
            temp = pdf_reader.pages[page_number - 1].extract_text()  # Subtract 1 to get the correct index  
            prev_text.append(temp)  
  
    with open(pdf_v2, 'rb') as file:    
        pdf_reader = PyPDF2.PdfReader(file)    
        curr_text = []  
        for page_number in v2_pages:  # Again, page_number is the actual page number  
            temp = pdf_reader.pages[page_number - 1].extract_text()  # Subtract 1 for the correct index  
            curr_text.append(temp)  

    try: 
    # Setting up the LLM client
        client = anthropic.Anthropic(
            # defaults to os.environ.get("ANTHROPIC_API_KEY")
            api_key= os.environ.get("ANTHROPIC_API_KEY") 
        )
        separator = '###'
        system_prompt = f'''You are expert in comparison of documents. You will be provided with two chunks of text data separated by {separator} extracted from financial records. It is possible that they might contain unstructured extracts of tabular data. 
        Compare the text by following these instruction and Notes strictly.

        Instructions:

        Step 1: Receive the two chunks of text data.
        Step 2: Thoroughly read and understand both text data.
        Step 3: Begin comparing the first chunk of text data with the second one.
        Step 4: Identify the any differences between the two text. This could be variations in information, different data in tables. 
        Step 5: From the set of Identified differences, Ignore formatting differences like fonts and differences that donot change the meaning of the data like parenthesis or page numbers.
        Step 6: Document the final set of identified differences between the two text chunks from Step 5.

        NOTE: Donot provide differences like page number which do not change meaning of the data or information
        NOTE: If there are no differences found then reply "No difference found in current comparison." 

        Output: Report of the final set of instructions found between the two chunks of text data in STEP 6.

        '''
        raw_differences = []
        for i in range(min(len(v1_pages),len(v1_pages))):

            user_prompt= f'''
            Previous Version:
            {prev_text[i]}

            {separator}

            New version:
            {curr_text[i]}

            '''
            message = client.messages.create(
                model="claude-3-opus-20240229",
                max_tokens=1000,
                temperature=0.0,
                system=system_prompt,
                messages=[
                    {"role": "user", "content": user_prompt}
                ]
            )
            
            raw_differences.append(message.content[0].text)
        
        categorized_differences = []
        for differences in raw_differences:
            temp = categorize_differences(differences)
            categorized_differences.append(temp)
        
        for i in range(min(len(v1_pages),len(v1_pages))):
            prefix = f'''Differences in Previous version's page {v1_pages[i]} and Current version's page {v2_pages[i]} are: \n'''
            final_differences = [prefix + s for s in categorized_differences]
        extra_message = ""
        if len(v1_pages) > len(v2_pages):  
            extra_pages = v1_pages[len(v2_pages):]
            extra_message = f'Previous version has {len(extra_pages)} extra pages: {extra_pages} ' 
        elif len(v2_pages) > len(v1_pages):  
            extra_pages = v2_pages[len(v1_pages):] 
            extra_message = f'New version has {len(extra_pages)} extra pages: {extra_pages} ' 
        
        final_differences.append(extra_message)
        comparison_output = "\n\n".join(final_differences)
        return comparison_output
    except BadRequestError as e:
        print("Error making Anthropics API call:", e)  
        return('error Your credit balance is too low to access the Claude API. Please go to Plans & Billing to upgrade or purchase credits.')   

@app.route('/chat', methods=['POST'])
def chat_session1():
    question=request.form['question']
    if 'pdf1' not in request.files:  
        return jsonify({'error': 'Missing files'}), 400        
    file = request.files['pdf1'] 
    #file = request.files["C:\\Users\\909663\\Downloads\\python_genai_requirements\\testing_samples\\Advantages and disadvantages matrix organization.pdf"]       
    if file.filename == '':  
        return jsonify({'error': 'No selected file'}), 400       
    # Generating paths for saving files  
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
    file.save(filepath)
    fname=file.filename
    #return(fname)
    output_str='Please select a image or PDF file'
    if file.content_type == "application/pdf":
        output_str=''
        doc = pymupdf.open(filepath)  # open document
        for page in doc:  # iterate through the pages
            zoom_x = 4  # Adjust zoom for better quality
            zoom_y = 4
            mat = fitz.Matrix(zoom_x, zoom_y)
            pix = page.get_pixmap(matrix=mat)  # render page to an image
            #pix.save("page-%i.png" % page.number)  # store image as a PNG
            save_dir = "uploaded_pdf_images"  # Adjust directory
            filename = f"page-{page.number}.png"  # Use f-string for cleaner formatting
            full_path = os.path.join(save_dir, filename)
            pix.save(full_path)
            with builtins.open(full_path, "rb") as f:
                image_data = f.read()
            result = client.analyze(image_data=image_data,visual_features=[VisualFeatures.READ])
            if result.read is not None:
                for line in result.read.blocks[0].lines:
                    for word in line.words:
                        #print(f"     Word: '{word.text}', Bounding polygon {word.bounding_polygon}, Confidence {word.confidence:.4f}")
                        output_str+=word.text+' '
    elif file.content_type in ["image/png", "image/jpeg","image/jpg"]:
        with builtins.open(filepath, "rb") as f:
            image_data = f.read()
        result = client.analyze(image_data=image_data,visual_features=[VisualFeatures.READ])
        output_str=''
        if result.read is not None:
            for line in result.read.blocks[0].lines:
                for word in line.words:
                    #print(f"     Word: '{word.text}', Bounding polygon {word.bounding_polygon}, Confidence {word.confidence:.4f}")
                    output_str+=word.text+' '
    print(output_str)
    if len(output_str) > 8196:
        output_str = output_str[:8195]
    response = openai.Completion.create(engine="bosonchatbot",prompt=f"Question: {question}\nContext: {output_str}\nAnswer:",temperature=1,max_tokens=1000,top_p=0.5,frequency_penalty=0,presence_penalty=0,stop=None)
    answer = response.choices[0].text.strip()
    answer=answer.split('\n\n')[0] 
    remove_files()
    #remove_files1()  
    return answer


@app.route('/textextract1',methods=['POST'])
def text_extraction():
    if 'pdf1' not in request.files:  
        return jsonify({'error': 'Missing files'}), 400        
    file = request.files['pdf1'] 
    #file = request.files["C:\\Users\\909663\\Downloads\\python_genai_requirements\\testing_samples\\Advantages and disadvantages matrix organization.pdf"]       
    if file.filename == '':  
        return jsonify({'error': 'No selected file'}), 400       
    # Generating paths for saving files  
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
    file.save(filepath)
    fname=file.filename
    #return(fname)
    output_str='Please select a image or PDF file'
    if file.content_type == "application/pdf":
        output_str=''
        doc = pymupdf.open(filepath)  # open document
        for page in doc:  # iterate through the pages
            zoom_x = 4  # Adjust zoom for better quality
            zoom_y = 4
            mat = fitz.Matrix(zoom_x, zoom_y)
            pix = page.get_pixmap(matrix=mat)  # render page to an image
            #pix.save("page-%i.png" % page.number)  # store image as a PNG
            save_dir = "uploaded_pdf_images"  # Adjust directory
            filename = f"page-{page.number}.png"  # Use f-string for cleaner formatting
            full_path = os.path.join(save_dir, filename)
            pix.save(full_path)
            with builtins.open(full_path, "rb") as f:
                image_data = f.read()
            result = client.analyze(image_data=image_data,visual_features=[VisualFeatures.READ])
            if result.read is not None:
                for line in result.read.blocks[0].lines:
                    for word in line.words:
                        #print(f"     Word: '{word.text}', Bounding polygon {word.bounding_polygon}, Confidence {word.confidence:.4f}")
                        output_str+=word.text+' '
    elif file.content_type in ["image/png", "image/jpeg","image/jpg"]:
        with builtins.open(filepath, "rb") as f:
            image_data = f.read()
        result = client.analyze(image_data=image_data,visual_features=[VisualFeatures.READ])
        output_str=''
        if result.read is not None:
            for line in result.read.blocks[0].lines:
                for word in line.words:
                    #print(f"     Word: '{word.text}', Bounding polygon {word.bounding_polygon}, Confidence {word.confidence:.4f}")
                    output_str+=word.text+' '
    print(output_str)
    extracted_data=[]
    extracted_data.append({
                #'filename': filename,
                'text': output_str,
                #'tables': tables,
                'word_count': 0
            })
    remove_files()
    #remove_files1()
    return extracted_data

def remove_files():
    directory_path = "uploaded_pdf_images"    
    # Loop through the files in the specified directory  
    for filename in os.listdir(directory_path):  
        # Check if the filename starts with "page0"  
        if filename.startswith("page"):  
            # Construct the full file path  
            file_path = os.path.join(directory_path, filename)  
            # Delete the file  
            os.remove(file_path)  
            print(f"Deleted {file_path}")

  
@app.route('/summary', methods=['POST'])
def summary():
    if 'pdf1' not in request.files:  
        return jsonify({'error': 'Missing files'}), 400        
    file = request.files['pdf1'] 
    #file = request.files["C:\\Users\\909663\\Downloads\\python_genai_requirements\\testing_samples\\Advantages and disadvantages matrix organization.pdf"]       
    if file.filename == '':  
        return jsonify({'error': 'No selected file'}), 400       
    # Generating paths for saving files  
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
    file.save(filepath)
    fname=file.filename
    #return(fname)
    output_str='Please select a image or PDF file'
    if file.content_type == "application/pdf":
        output_str=''
        doc = pymupdf.open(filepath)  # open document
        for page in doc:  # iterate through the pages
            zoom_x = 4  # Adjust zoom for better quality
            zoom_y = 4
            mat = fitz.Matrix(zoom_x, zoom_y)
            pix = page.get_pixmap(matrix=mat)  # render page to an image
            #pix.save("page-%i.png" % page.number)  # store image as a PNG
            save_dir = "uploaded_pdf_images"  # Adjust directory
            filename = f"page-{page.number}.png"  # Use f-string for cleaner formatting
            full_path = os.path.join(save_dir, filename)
            pix.save(full_path)
            with builtins.open(full_path, "rb") as f:
                image_data = f.read()
            result = client.analyze(image_data=image_data,visual_features=[VisualFeatures.READ])
            if result.read is not None:
                for line in result.read.blocks[0].lines:
                    for word in line.words:
                        #print(f"     Word: '{word.text}', Bounding polygon {word.bounding_polygon}, Confidence {word.confidence:.4f}")
                        output_str+=word.text+' '
    elif file.content_type in ["image/png", "image/jpeg","image/jpg"]:
        with builtins.open(filepath, "rb") as f:
            image_data = f.read()
        result = client.analyze(image_data=image_data,visual_features=[VisualFeatures.READ])
        output_str=''
        if result.read is not None:
            for line in result.read.blocks[0].lines:
                for word in line.words:
                    #print(f"     Word: '{word.text}', Bounding polygon {word.bounding_polygon}, Confidence {word.confidence:.4f}")
                    output_str+=word.text+' '
    print(output_str)
    if len(output_str) > 8196:
        output_str = output_str[:8195]
    response = openai.Completion.create(engine="bosonchatbot",prompt=f"Question: {'Provide a summary with all the key points in the given context'}\nContext: {output_str}\nAnswer:",temperature=1,max_tokens=1000,top_p=0.5,frequency_penalty=0,presence_penalty=0,stop=None)
    answer = response.choices[0].text.strip()
    answer=answer.split('\n\n')[0]
    extracted_data=[]
    extracted_data.append({
                #'filename': filename,
                'text': answer,
                #'tables': tables,
                'word_count': 0
            })
    remove_files()
    #remove_files1()
    return extracted_data



if __name__ == '__main__':
   app.run()